package com.tiendafunciona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendafuncionaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendafuncionaApplication.class, args);
	}

}
